class NodeSlot {

	constructor( node, name, output ) {

		this.node = node;
		this.name = name;
		this.output = output;

	}

}

export default NodeSlot;
