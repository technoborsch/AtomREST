// Split strategy constants
export const CENTER = 0;
export const AVERAGE = 1;
export const SAH = 2;

export const NOT_INTERSECTED = 0;
export const INTERSECTED = 1;
export const CONTAINED = 2;
